CREATE DATABASE computar;

USE computar;

CREATE TABLE instrutor (
	codigo_instrutor INT(5),
    nome_instrutor VARCHAR(20),
    endereco_instrutor VARCHAR(45),
    telefone_instrutor VARCHAR(20),
    curso_instrutor VARCHAR(30),
    observacoes VARCHAR(50),
    PRIMARY KEY (codigo_instrutor)
);

CREATE TABLE curso (
		codigo_curso INT(5),
        curso_nome VARCHAR(30),
        turno_curso VARCHAR(5),
        carga_horaria INT(10),
        data_inicio DATE,
        data_termino DATE,
        observacoes VARCHAR(50),
        id_codigo_instrutor INT(5),
        PRIMARY KEY (codigo_curso),
        FOREIGN KEY (id_codigo_instrutor) REFERENCES instrutor (codigo_instrutor)
);

CREATE TABLE aluno (
	codigo_aluno INT(5),
    nome_aluno VARCHAR(20),
    endereco_aluno VARCHAR(45),
    telefone_aluno VARCHAR(20),
    observacoes VARCHAR(50),
    curso_codigo_curso INT(5),
    instrutor_codigo_instrutor INT(5),
    PRIMARY KEY (codigo_aluno),
    FOREIGN KEY (curso_codigo_curso) REFERENCES curso (codigo_curso),
    FOREIGN KEY (instrutor_codigo_instrutor) REFERENCES instrutor (codigo_instrutor)
);

INSERT INTO instrutor
(codigo_instrutor, nome_instrutor, endereco_instrutor, telefone_instrutor, curso_instrutor, observacoes) VALUES
(1, "Rubem Cândido", "Rua Santa Luiza", "478954", "Banco de Dados", NULL),
(2, "Cláudio Iwakami", "Rua Japonês", "2554565", "Lógica de Programação", NULL),
(3, "Luiza Lima", "Rua dos Anjos", "8974112", "Front-End", NULL),
(4, "Julia Maria", "Rua Santa Tereza", "9992455", "React", NULL),
(5, "Gustavo Guanabara", "Rua Curso em Vídeo", "148586", "Back-End", NULL);

INSERT INTO curso
(codigo_curso, curso_nome, turno_curso, carga_horaria, data_inicio, data_termino, id_codigo_instrutor, observacoes) VALUES
(01, "Lógica de Programação", "Manhã", 100, "2021-10-10", "2021-11-10", 2, NULL),
(02, "Back-End", "Tarde", 300, "2021-03-25", "2021-05-25", 5, NULL),
(03, "Front-End", "Noite", 300, "2021-08-30", "2021-10-30", 3, NULL),
(04, "Banco de Dados", "Tarde", 250, "2021-01-09", "2021-02-09", 1, NULL),
(05, "React", "Noite", 150, "2021-12-26", "2022-01-26", 4, NULL);

INSERT INTO aluno
(codigo_aluno, nome_aluno, endereco_aluno, telefone_aluno, curso_codigo_curso, instrutor_codigo_instrutor, observacoes) VALUES
(001, "Ana Cláudia", "Rua Mariana", "1111111", 04, 1, NULL),
(002, "Bruno Henrique", "Rua Crakeada", "22222", 02, 5, NULL),
(003, "Luiz Gabriel", "Rua C#", "333333", 03, 3, NULL),
(004, "Matheus Oliveira", "Rua Traider", "444444", 05, 4, NULL),
(005, "Gustavo Roberto", "Rua Carros", "555555", 04, 1, NULL),
(006, "Rafael Archanjo", "Rua Abençoada", "66666", 03, 3, NULL),
(007, "Diogo Oishi", "Rua dos Japas", "777777", 01, 2, NULL),
(008, "Deyvidy Bruno", "Rua São Paulo", "88888", 05, 4, NULL);

-- Verificar se os relacionamentos permitem: Consultar quais são os alunos de uma determinada turma e qual o instrutor
SELECT nome_aluno, nome_instrutor, curso_nome FROM aluno, curso, instrutor 
WHERE instrutor_codigo_instrutor = codigo_instrutor AND curso_codigo_curso = codigo_curso;

-- Verificar se os relacionamentos permitem: Consultar um aluno e mostrar qual é sua turma e qual instrutor da turma
SELECT nome_instrutor, curso_nome FROM aluno, curso, instrutor 
WHERE instrutor_codigo_instrutor = codigo_instrutor AND curso_codigo_curso = codigo_curso AND nome_aluno = "Ana Cláudia";

-- Realizar outros testes de consultas
SELECT nome_aluno FROM aluno
INNER JOIN instrutor ON instrutor_codigo_instrutor = 4;

SELECT nome_aluno FROM aluno, curso
WHERE curso_codigo_curso = 03;

SELECT nome_aluno FROM aluno
ORDER BY nome_aluno ASC;

SELECT curso_nome FROM curso
ORDER BY curso_nome ASC;

-- Criação de Views.
CREATE VIEW vw_instrutor_curso
AS
SELECT nome_instrutor, curso_nome
FROM curso
INNER JOIN instrutor
ON codigo_instrutor = id_codigo_instrutor;

SELECT nome_instrutor, curso_nome FROM vw_instrutor_curso;















